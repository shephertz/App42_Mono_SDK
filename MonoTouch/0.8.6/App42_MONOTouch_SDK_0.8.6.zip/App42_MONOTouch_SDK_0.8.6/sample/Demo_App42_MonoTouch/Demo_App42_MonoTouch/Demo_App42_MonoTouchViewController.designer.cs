//
// This file has been generated automatically by MonoDevelop to store outlets and
// actions made in the Xcode designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using MonoTouch.Foundation;

namespace Demo_App42_MonoTouch
{
	[Register ("Demo_App42_MonoTouchViewController")]
	partial class Demo_App42_MonoTouchViewController
	{

		[Outlet]
		MonoTouch.UIKit.UIButton aButton { get; set; }
		
		[Action ("HandleButtonTouch:")]
		partial void HandleButtonTouch (MonoTouch.Foundation.NSObject sender);

		void ReleaseDesignerOutlets ()
		{
		}
	}
}
